import { Routes } from '@angular/router';

export const rootRouterConfig: Routes = [
  { 
    path: '', 
    redirectTo: 'home/two', 
    pathMatch: 'full' 
  },
  // { 
  //   path: '', 
  //   redirectTo: 'home/demos', 
  //   pathMatch: 'full' 
  // },
  { 
    path: 'home', 
    loadChildren: './views/home/home.module#HomeModule'
  },
   { 
    path: 'home', 
    loadChildren: './views/home/home.module#HomeModule'
  },
  // { 
  //   path: 'home', 
  //   loadChildren: './views/home/home-two.component#HomeTwoComponent'
  // },
  { 
    path: '**', 
    redirectTo: 'home/one'
  }
];

